Hi there! I see that you are up for playing or recording a tune, here's the lowdown: 
 
1. PlayThatTune : Go ahead and groove with the txt file in the ./play directory
2. RecordThatTune : Capture your performance by saving it into the txt file. If you want to share your musical masterpiece, send me an email with the txt file attached, I will place them in the play directory